const caixaPrincipal = document.querySelector(".caixa-principal");
const caixaPerguntas = document.querySelector(".caixa-perguntas");
const caixaAlternativas = document.querySelector(".caixa-alternativas");
const caixaResultado = document.querySelector(".caixa-resultado");
const textoResultado = document.querySelector(".texto-resultado");

const perguntas = [
    {
        enunciado: "Você é o líder de uma equipe de especialistas em IA, e está prestes a tomar uma decisão fundamental para o desenvolvimento da tecnologia. O futuro da IA está em suas mãos.",
        alternativas: [
            {
                texto: "Isso é assustador!",
                afirmacao: "No início ficou com medo do que essa tecnologia pode fazer. "
            },
            {
                texto: "Isso é maravilhoso!",
                afirmacao: "Quis saber como usar IA no seu dia a dia."
            }
        ]
    },
    {
        enunciado: "Escolha uma das opções abaixo para decidir o rumo da IA:",
        alternativas: [
            {
                texto: " Você opta por um desenvolvimento de IA que prioriza a transparência completa em relação aos algoritmos e processos de tomada de decisão. As IA devem ser projetadas para serem explicáveis e auditáveis, garantindo que todas as suas ações possam ser rastreadas e compreendidas. Assegurar que a IA não tome decisões autônomas em áreas críticas sem supervisão humana é uma prioridade.",
                afirmacao: "Conseguiu utilizar a IA para buscar informações úteis."
            },
            {
                texto: "Você escolhe permitir maior autonomia e inovação nas tecnologias de IA. A ênfase está em criar sistemas que possam aprender e evoluir de forma independente, explorando novas abordagens e soluções sem restrições rígidas. A transparência e a supervisão são secundárias à capacidade da IA de operar de forma autônoma e inovadora.",
                afirmacao: "Sentiu mais facilidade em utilizar seus próprios recursos para escrever seu trabalho."
            }
        ]
    },
    {
        enunciado: "Após um ano de implementação do padrão de transparência e controle, a equipe de IA descobre uma nova tecnologia emergente que promete aumentar a eficiência das IA de forma significativa. No entanto, essa tecnologia é complexa e seus algoritmos são altamente sofisticados, tornando a transparência e a auditabilidade um desafio. Agora, você deve decidir como proceder com essa nova tecnologia.",
        alternativas: [
            {
                texto: " Você decide integrar a nova tecnologia de forma gradual, começando com projetos menores e realizando revisões rigorosas a cada etapa. A equipe estabelecerá um processo de validação para garantir que a nova tecnologia se alinhe com os padrões de transparência e controle. Os dados e decisões serão monitorados e auditados continuamente durante a integração.",
                afirmacao: "Vem impulsionando a inovação na área de IA e luta para abrir novos caminhos profissionais com IA."
            },
            {
                texto: "Você opta por adotar a nova tecnologia de forma mais rápida, implementando-a em projetos maiores com a adição de provisões especiais para monitoramento intensivo. Embora você aceite um certo nível de risco, garante que haja equipes dedicadas para acompanhar e responder rapidamente a quaisquer problemas ou desvios.",
                afirmacao: "Sua preocupação com as pessoas motivou a criar um grupo de estudos entre trabalhadores para discutir meios de utilização de IA de forma ética."
            }
        ]
    },
    {
        enunciado: "Qual é a principal função de uma função de ativação em uma rede neural?",
        alternativas: [
            {
                texto: " Armazenar dados temporários",
                afirmacao: "Notou também que muitas pessoas não sabem ainda utilizar as ferramentas tradicionais e decidiu compartilhar seus conhecimentos de design utilizando ferramentas de pintura digital para iniciantes."
            },
            {
                texto: "Transformar a entrada de um neurônio para determinar a saída",
                afirmacao: "Acelerou o processo de criação de trabalhos utilizando geradores de imagem e agora consegue ensinar pessoas que sentem dificuldades em desenhar manualmente como utilizar também!"
            }
        ]
    },
    {
        enunciado: "Qual é o objetivo principal do aprendizado supervisionado em Inteligência Artificial? ",
        alternativas: [
            {
                texto: "Melhorar a eficiência de hardware",
                afirmacao: "Infelizmente passou a utilizar a IA para fazer todas suas tarefas e agora se sente dependente da IA para tudo."
            },
            {
                texto: "Treinar um modelo para fazer previsões ou classificações com base em dados rotulados",
                afirmacao: "Percebeu que toda IA reproduz orientações baseadas na empresa que programou e muito do que o chat escrevia não refletia o que pensava e por isso sabe que os textos gerados pela IA devem servir como auxílio e não resultado final. "
            }
        ]
    },
];


let atual = 0;
let perguntaAtual;
let historiaFinal = "";

function mostraPergunta() {
    if (atual >= perguntas.length) {
        mostraResultado();
        return;
    }
    perguntaAtual = perguntas[atual];
    caixaPerguntas.textContent = perguntaAtual.enunciado;
    caixaAlternativas.textContent = "";
    mostraAlternativas();
}

function mostraAlternativas(){
    for(const alternativa of perguntaAtual.alternativas) {
        const botaoAlternativas = document.createElement("button");
        botaoAlternativas.textContent = alternativa.texto;
        botaoAlternativas.addEventListener("click", () => respostaSelecionada(alternativa));
        caixaAlternativas.appendChild(botaoAlternativas);
    }
}

function respostaSelecionada(opcaoSelecionada) {
    const afirmacoes = opcaoSelecionada.afirmacao;
    historiaFinal += afirmacoes + " ";
    atual++;
    mostraPergunta();
}

function mostraResultado() {
    caixaPerguntas.textContent = "Em 2049...";
    textoResultado.textContent = historiaFinal;
    caixaAlternativas.textContent = "";
}

mostraPergunta();
